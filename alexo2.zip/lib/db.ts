import mysql from 'mysql2/promise';

// Lazy-initialized pool - prevents build-time errors when DATABASE_URL is not yet set
let _pool: mysql.Pool | null = null;

function getPool(): mysql.Pool {
    if (!_pool) {
        const connectionString = process.env.DATABASE_URL;
        if (!connectionString) {
            throw new Error('DATABASE_URL is not defined');
        }
        _pool = mysql.createPool(connectionString);
    }
    return _pool;
}

export const pool = new Proxy({} as mysql.Pool, {
    get(_, prop) {
        return (getPool() as any)[prop];
    }
});

export const query = async (sql: string, params?: any[]) => {
    const [rows, fields] = await getPool().execute(sql, params);
    return rows;
};

export const getClient = async () => {
    return await getPool().getConnection();
};
